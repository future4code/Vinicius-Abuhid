const arrayDePalavras = ["Oi", "sumida", "tudo", "bem", "sdds"]
let mensagem = ""

for(let palavra of arrayDePalavras) {
    // mensagem = mensagem + palavra + " "
    mensagem += palavra + " "
}

console.log(mensagem)