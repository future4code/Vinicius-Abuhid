for(let i = 0; i <=10; i++) {
    // console.log(i)
    if(i % 2 === 0) {
        console.log(i + "é par")
    } else {
        console.log(i + "é ímpar")
    }
}

// let i = 0

// while (i <= 10) {
//     if(i % 2 === 0) {
//         console.log(i + "é par")
//     } else {
//         console.log(i + "é ímpar")
//     }
// }