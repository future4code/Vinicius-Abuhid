const numeros = [11, 15, 18, 14, 12, 13]
let maior = numeros[0]

for(let i = 0; i < 6; i++) {
    const elemento = numeros[i]

    if(elemento > maior) {
        maior = elemento
    }
}

console.log(maior)

// const numeros = [11, 15, 18, 14, 12, 13]
// let maior = numeros[0]

// for(let i = 0; i < numeros.length; i++) {
//     if(elemento > maior) {
//         maior = elemento
//     }
// }

// console.log(maior)