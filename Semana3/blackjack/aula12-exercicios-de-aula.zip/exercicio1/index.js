let numeroDoUsuario = Number(prompt("Digite um número"))
let soma = 0

while(numeroDoUsuario !== 0) {
    soma = soma + numeroDoUsuario
    numeroDoUsuario = Number(prompt("Digite um número"))
    // console.log(numeroDoUsuario)
}

console.log(soma)


// let numeroDoUsuario = Number(prompt("Digite um número"))
// let soma = numeroDoUsuario

// while(numeroDoUsuario !== 0) {
//     let numeroDoUsuario = Number(prompt("Digite um número"))
//     soma = soma + numeroDoUsuario
// }

// console.log(soma)