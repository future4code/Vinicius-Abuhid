import React from "react";
import { connect } from "react-redux";

class Planner extends React.Component {
  render() {
    return <div />;
  }
}

export default connect()(Planner);
